#include <iostream>
#include <string>
#include <vector>
#include <map>

using namespace std;


char my_tolower(char c) {
    if (c >= 'A' && c <= 'Z') return c + 32;
    return c;
}

bool my_isalpha(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

bool my_isspace(char c) {
    return c == ' ';
}

int my_min(int a, int b) {
    return a < b ? a : b;
}


int BF(const string &text, const string &pattern) {
    int n = text.size();
    int m = pattern.size();
    for (int i = 0; i <= n - m; i++) {
        int j = 0;
        while (j < m && text[i + j] == pattern[j]) {
            j++;
        }
        if (j == m) return i;
    }
    return -1;
}

vector<int> BF_FindAllPos(const string &text, const string &pat)
{
    vector<int> posList;
    int idx = 0;
    int n = text.size();
    int m = pat.size();
    while(idx <= n - m)
    {
        int ret = BF(text.substr(idx), pat);
        if(ret == -1) break;
        idx += ret;
        posList.push_back(idx);
        idx += m;
    }
    return posList;
}

string replaceTextBF(string text, string oldStr, string newStr) {
    int pos = BF(text, oldStr);
    while (pos != -1) {
        text.replace(pos, oldStr.size(), newStr);
        pos = BF(text, oldStr);
    }
    return text;
}


int BF_SingleMatch(const string &text, const string &pattern) {
    int n = text.size();
    int m = pattern.size();
    if (m == 0 || n < m) return -1;

    for (int i = 0; i <= n - m; i++) {
        int j = 0;
        while (j < m && text[i + j] == pattern[j]) {
            j++;
        }
        if (j == m) {
            return i;
        }
    }
    return -1;
}

void singleSubStringMatch(const string &text) {
    if (text.empty()) {
        cout << "���������ı���\n";
        return;
    }
    string pat;
    cout << "������Ҫƥ����ִ���";
    cin >> pat;

    int pos = BF_SingleMatch(text, pat);
    if (pos == -1) {
        cout << "δƥ�䵽���ִ���" << endl;
    } else {
        cout << "�ִ��״�ƥ��λ�ã�" << pos << endl;
    }
}


string preProcess(const string &text) {
    string res;
    for (char ch : text) {
        if (my_isalpha(ch)) {
            res += my_tolower(ch);
        } else if (my_isspace(ch)) {
            res += ' ';
        }
    }
    return res;
}


vector<string> splitWords(const string &text) {
    vector<string> words;
    string word;
    for (char c : text) {
        if (c == ' ') {
            if (!word.empty()) {
                words.push_back(word);
                word.clear();
            }
        } else {
            word += c;
        }
    }
    if (!word.empty()) words.push_back(word);
    return words;
}

vector<string> splitSentences(const string &text) {
    vector<string> sentences;
    string cur;
    for (char c : text) {
        cur += c;
        if (c == '.' || c == '?' || c == '!') {
            sentences.push_back(cur);
            cur.clear();
        }
    }
    if (!cur.empty()) sentences.push_back(cur);
    return sentences;
}


map<string, int> countFreq(const vector<string> &words) {
    map<string, int> freq;
    for (const string &w : words) freq[w]++;
    return freq;
}


int searchWord(const map<string, int> &freq, const string &key) {
    for (auto &p : freq) {
        if (p.first == key) return p.second;
    }
    return 0;
}


void showBasicInfo(const string &text, const vector<string> &words) {
    vector<string> sentences = splitSentences(text);
    cout << "\n===== ����ͳ�� =====" << endl;
    cout << "���ַ�����" << text.size() << endl;
    cout << "�ܵ�������" << words.size() << endl;
    cout << "�ܾ�������" << sentences.size() << endl;
}


void showFreq(const map<string, int> &freq) {
    cout << "\n===== ��Ƶͳ�� =====" << endl;
    for (const auto &p : freq) {
        cout << p.first << " : " << p.second << endl;
    }
}


void showKeyWords(const map<string, int> &freq) {
    cout << "\n�ؼ��ʣ�ǰ5����";
    int count = 0;
    for (const auto &p : freq) {
        if (count++ >= 5) break;
        cout << p.first << " ";
    }
    cout << endl;
}


void showSummary(const string &text) {
    vector<string> sentences = splitSentences(text);
    cout << "\n===== �ı�ժҪ =====" << endl;
    int n = my_min(2, (int)sentences.size());
    for (int i = 0; i < n; i++) {
        cout << sentences[i] << endl;
    }
}


void searchAllSub(const string &srcText)
{
    if(srcText.empty()){
        cout<<"���������ı���\n";
        return;
    }
    string key;
    cout<<"��������Ҫ���ҵ��Ӵ���";
    cin>>key;
    vector<int> posArr = BF_FindAllPos(srcText, key);
    if(posArr.empty()){
        cout<<"δ���ı����ҵ��ùؼ���\n";
        return;
    }
    cout<<"\n===== ƥ��λ�ã��±��0��ʼ��=====\n";
    for(int p : posArr){
        cout<<"ƥ����ʼ�±꣺"<<p<<endl;
    }
    cout<<"�ܹ�ƥ�䣺"<<posArr.size()<<"��\n";
}


string highlightKey(string src, const string &key)
{
    vector<int> posList = BF_FindAllPos(src, key);
    string res;
    int keylen = key.size();
    for(auto it = posList.rbegin(); it != posList.rend(); ++it)
    {
        int pos = *it;
        string head = src.substr(0, pos);
        string mid = "��" + key + "��";
        string tail = src.substr(pos + keylen);
        src = head + mid + tail;
    }
    return src;
}

void showHighlightText(const string &srcText)
{
    if(srcText.empty()){
        cout<<"���������ı���\n";
        return;
    }
    string key;
    cout<<"������Ҫ�����Ĺؼ��ʣ�";
    cin>>key;
    string out = highlightKey(srcText, key);
    cout<<"\n===== ������� =====\n"<<out<<endl;
}


struct ErrorInfo {
    string type; int lineNo; string content; string hint;
};
map<string, bool> initDict() {
    map<string, bool> dict;
    vector<string> baseWords = {"i","you","he","she","is","am","are","good","bad","book","school"};
    for (auto w : baseWords) dict[w]=1;
    return dict;
}
vector<ErrorInfo> checkSpelling(const vector<string>& words, map<string, bool>& dict) {
    vector<ErrorInfo> e;
    for(int i=0;i<words.size();i++){
        string w=words[i];
        for (int j=0;j<w.size();j++) w[j] = my_tolower(w[j]);
        if(!dict.count(w)) e.push_back({"ƴд����",i+1,words[i],"���ڴʵ�"});
    }
    return e;
}
vector<ErrorInfo> checkSentenceStart(const vector<string>& s){
    vector<ErrorInfo> e;
    for(int i=0;i<s.size();i++)
        if(!s[i].empty() && s[i][0] >= 'a' && s[i][0] <= 'z')
            e.push_back({"����δ��д",i+1,s[i],"����ĸ��д"});
    return e;
}
vector<ErrorInfo> checkSentenceEnd(const vector<string>& s){
    vector<ErrorInfo> e;
    for(int i=0;i<s.size();i++)
        if(!s[i].empty()){
            char c=s[i].back();
            if(c!='.'&&c!='?'&&c!='!')
                e.push_back({"��ĩ�ޱ��",i+1,s[i],"��.?!��β"});
        }
    return e;
}
void showGrammarErrors(vector<ErrorInfo> errors){
    if(errors.empty()){cout<<"\n���﷨����\n";return;}
    cout<<"\n===== �﷨���� =====\n";
    for(auto& e:errors)
        cout<<"["<<e.type<<"] "<<e.lineNo<<"��"<<e.content<<" �� "<<e.hint<<endl;
}
void grammarCheck(string text, vector<string> words){
    auto dict=initDict(); auto s=splitSentences(text);
    auto e1=checkSpelling(words,dict),e2=checkSentenceStart(s),e3=checkSentenceEnd(s);
    vector<ErrorInfo> all;
    all.insert(all.end(),e1.begin(),e1.end());
    all.insert(all.end(),e2.begin(),e2.end());
    all.insert(all.end(),e3.begin(),e3.end());
    showGrammarErrors(all);
}


void menu() {
    cout << "\n===== �����ı�����ϵͳ��V4 ���հ棩 =====" << endl;
    cout << "1. �����ı�" << endl;
    cout << "2. ����ͳ��" << endl;
    cout << "3. �ִʽ��" << endl;
    cout << "4. ��Ƶͳ��" << endl;
    cout << "5. �ؼ�����ȡ" << endl;
    cout << "6. �ı�ժҪ" << endl;
    cout << "7. ���ҵ���" << endl;
    cout << "8. �����滻" << endl;
    cout << "9. �﷨���" << endl;
    cout << "10. ȫ���Ӵ�����" << endl;
    cout << "11. �ؼ��ʸ���" << endl;
    cout << "12. �ִ�ƥ�䣨�״�λ�ã���������" << endl;
    cout << "0. �˳�" << endl;
    cout << "������ѡ�";
}
int main() {
    string text;
    vector<string> words;
    map<string, int> freq;

    cout << "===== ��ӭʹ���ı�����ϵͳ =====" << endl;

    while (true) {
        menu();
        int op;
        cin >> op;
        cin.ignore();

        if (op == 0) {
            cout << "�������" << endl;
            break;
        }

        switch (op) {
            case 1: {
                cout << "\n�������ı���" << endl;
                getline(cin, text);
                string clean = preProcess(text);
                words = splitWords(clean);
                freq = countFreq(words);
                cout << "�ı�������ɣ�" << endl;
                break;
            }
            case 2:
                if (words.empty()) cout << "���������ı���" << endl;
                else showBasicInfo(text, words);
                break;
            case 3:
                if (words.empty()) cout << "���������ı���" << endl;
                else {
                    cout << "\n===== �ִʽ�� =====" << endl;
                    for (const string& w : words) cout << w << " ";
                    cout << endl;
                }
                break;
            case 4:
                if (freq.empty()) cout << "���������ı���" << endl;
                else showFreq(freq);
                break;
            case 5:
                if (freq.empty()) cout << "���������ı���" << endl;
                else showKeyWords(freq);
                break;
            case 6:
                if (text.empty()) cout << "���������ı���" << endl;
                else showSummary(text);
                break;
            case 7: {
                if (freq.empty()) { cout << "���������ı���" << endl; break; }
                string key; cout << "������Ҫ���ҵĵ��ʣ�"; cin >> key;
                for (int i=0;i<key.size();i++) key[i] = my_tolower(key[i]);
                cout << "���ִ�����" << searchWord(freq, key) << endl;
                break;
            }
            case 8: {
                if (text.empty()) { cout << "���������ı���" << endl; break; }
                string oldS, newS; cout << "���ң�"; cin >> oldS;
                cout << "�滻Ϊ��"; cin >> newS;
                text = replaceTextBF(text, oldS, newS);
                string clean = preProcess(text);
                words = splitWords(clean);
                freq = countFreq(words);
                cout << "�滻��ɣ�" << endl;
                break;
            }
            case 9:
                grammarCheck(text, words);
                break;
            case 10:
                searchAllSub(text);
                break;
            case 11:
                showHighlightText(text);
                break;
            case 12:
                singleSubStringMatch(text);
                break;
            default:
                cout << "��Чѡ�" << endl;
        }
    }
    return 0;
}
