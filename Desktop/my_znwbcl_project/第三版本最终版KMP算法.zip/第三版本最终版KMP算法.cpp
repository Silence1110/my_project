#include <iostream>
#include <string>
#include <vector>
#include <map>

using namespace std;

// ===================== ��д�滻���п⺯�� =====================
char my_tolower(char c) {
    if (c >= 'A' && c <= 'Z') return c + 32;
    return c;
}

bool my_isalpha(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

bool my_isspace(char c) {
    return c == ' ';
}

int my_min(int a, int b) {
    return a < b ? a : b;
}

// ===================== ��KMP �㷨���滻 BF�� =====================
vector<int> getNext(const string &pattern) {
    int m = pattern.size();
    vector<int> next(m, 0);
    int j = 0;
    for (int i = 1; i < m; i++) {
        while (j > 0 && pattern[i] != pattern[j]) {
            j = next[j - 1];
        }
        if (pattern[i] == pattern[j]) {
            j++;
        }
        next[i] = j;
    }
    return next;
}

int KMP(const string &text, const string &pattern) {
    int n = text.size();
    int m = pattern.size();
    if (m == 0 || n < m) return -1;

    vector<int> next = getNext(pattern);
    int j = 0;
    for (int i = 0; i < n; i++) {
        while (j > 0 && text[i] != pattern[j]) {
            j = next[j - 1];
        }
        if (text[i] == pattern[j]) {
            j++;
        }
        if (j == m) {
            return i - m + 1;
        }
    }
    return -1;
}

string replaceTextKMP(string text, string oldStr, string newStr) {
    int pos = KMP(text, oldStr);
    while (pos != -1) {
        text.replace(pos, oldStr.size(), newStr);
        pos = KMP(text, oldStr);
    }
    return text;
}

// ===================== �ı�Ԥ�������Ѹ�����д������ =====================
string preProcess(const string &text) {
    string res;
    for (char ch : text) {
        if (my_isalpha(ch)) {
            res += my_tolower(ch);
        } else if (my_isspace(ch)) {
            res += ' ';
        }
    }
    return res;
}

// ===================== �ִʣ���дʵ�֣�ȥ�� stringstream =====================
vector<string> splitWords(const string &text) {
    vector<string> words;
    string word;
    for (char c : text) {
        if (c == ' ') {
            if (!word.empty()) {
                words.push_back(word);
                word.clear();
            }
        } else {
            word += c;
        }
    }
    if (!word.empty()) words.push_back(word);
    return words;
}

// ===================== �־䣺��ȫ���� =====================
vector<string> splitSentences(const string &text) {
    vector<string> sentences;
    string cur;
    for (char c : text) {
        cur += c;
        if (c == '.' || c == '?' || c == '!') {
            sentences.push_back(cur);
            cur.clear();
        }
    }
    if (!cur.empty()) sentences.push_back(cur);
    return sentences;
}

// ===================== ��Ƶͳ�ƣ���ȫ���� =====================
map<string, int> countFreq(const vector<string> &words) {
    map<string, int> freq;
    for (const string &w : words) freq[w]++;
    return freq;
}

// ===================== ���ҵ��ʣ���ȫ���� =====================
int searchWord(const map<string, int> &freq, const string &key) {
    for (auto &p : freq) {
        if (p.first == key) return p.second;
    }
    return 0;
}

// ===================== ����ͳ�ƣ���ȫ���� =====================
void showBasicInfo(const string &text, const vector<string> &words) {
    vector<string> sentences = splitSentences(text);
    cout << "\n===== ����ͳ�� =====" << endl;
    cout << "���ַ�����" << text.size() << endl;
    cout << "�ܵ�������" << words.size() << endl;
    cout << "�ܾ�������" << sentences.size() << endl;
}

// ===================== ��ʾ��Ƶ����ȫ���� =====================
void showFreq(const map<string, int> &freq) {
    cout << "\n===== ��Ƶͳ�� =====" << endl;
    for (const auto &p : freq) {
        cout << p.first << " : " << p.second << endl;
    }
}

// ===================== �ؼ��ʣ���ȫ���� =====================
void showKeyWords(const map<string, int> &freq) {
    cout << "\n�ؼ��ʣ�ǰ5����";
    int count = 0;
    for (const auto &p : freq) {
        if (count++ >= 5) break;
        cout << p.first << " ";
    }
    cout << endl;
}

// ===================== ժҪ��������д min =====================
void showSummary(const string &text) {
    vector<string> sentences = splitSentences(text);
    cout << "\n===== �ı�ժҪ =====" << endl;
    int n = my_min(2, (int)sentences.size());
    for (int i = 0; i < n; i++) {
        cout << sentences[i] << endl;
    }
}

// ===================== �﷨���ģ�飺��ȫ���� =====================
struct ErrorInfo {
    string type; int lineNo; string content; string hint;
};
map<string, bool> initDict() {
    map<string, bool> dict;
    vector<string> baseWords = {"i","you","he","she","is","am","are","good","bad","book","school"};
    for (auto w : baseWords) dict[w]=1;
    return dict;
}
vector<ErrorInfo> checkSpelling(const vector<string>& words, map<string, bool>& dict) {
    vector<ErrorInfo> e;
    for(int i=0;i<words.size();i++){
        string w=words[i];
        for (int j=0;j<w.size();j++) w[j] = my_tolower(w[j]);
        if(!dict.count(w)) e.push_back({"ƴд����",i+1,words[i],"���ڴʵ�"});
    }
    return e;
}
vector<ErrorInfo> checkSentenceStart(const vector<string>& s){
    vector<ErrorInfo> e;
    for(int i=0;i<s.size();i++)
        if(!s[i].empty() && s[i][0] >= 'a' && s[i][0] <= 'z')
            e.push_back({"����δ��д",i+1,s[i],"����ĸ��д"});
    return e;
}
vector<ErrorInfo> checkSentenceEnd(const vector<string>& s){
    vector<ErrorInfo> e;
    for(int i=0;i<s.size();i++)
        if(!s[i].empty()){
            char c=s[i].back();
            if(c!='.'&&c!='?'&&c!='!')
                e.push_back({"��ĩ�ޱ��",i+1,s[i],"��.?!��β"});
        }
    return e;
}
void showGrammarErrors(vector<ErrorInfo> errors){
    if(errors.empty()){cout<<"\n? ���﷨����\n";return;}
    cout<<"\n===== �﷨���� =====\n";
    for(auto& e:errors)
        cout<<"["<<e.type<<"] "<<e.lineNo<<"��"<<e.content<<" �� "<<e.hint<<endl;
}
void grammarCheck(string text, vector<string> words){
    auto dict=initDict(); auto s=splitSentences(text);
    auto e1=checkSpelling(words,dict),e2=checkSentenceStart(s),e3=checkSentenceEnd(s);
    vector<ErrorInfo> all;
    all.insert(all.end(),e1.begin(),e1.end());
    all.insert(all.end(),e2.begin(),e2.end());
    all.insert(all.end(),e3.begin(),e3.end());
    showGrammarErrors(all);
}

// ===================== �˵�������Ϊ KMP =====================
void menu() {
    cout << "\n===== �����ı�����ϵͳ����KMP�㷨�� =====" << endl;
    cout << "1. �����ı�" << endl;
    cout << "2. ����ͳ��" << endl;
    cout << "3. �ִʽ��" << endl;
    cout << "4. ��Ƶͳ��" << endl;
    cout << "5. �ؼ�����ȡ" << endl;
    cout << "6. �ı�ժҪ" << endl;
    cout << "7. ���ҵ���" << endl;
    cout << "8. �����滻" << endl;
    cout << "9. �﷨���" << endl;
    cout << "0. �˳�" << endl;
    cout << "������ѡ�";
}

// ===================== ������ =====================
int main() {
    string text;
    vector<string> words;
    map<string, int> freq;

    cout << "===== ��ӭʹ���ı�����ϵͳ =====" << endl;

    while (true) {
        menu();
        int op;
        cin >> op;
        cin.ignore();

        if (op == 0) {
            cout << "�������" << endl;
            break;
        }

        switch (op) {
            case 1: {
                cout << "\n�������ı���" << endl;
                getline(cin, text);
                string clean = preProcess(text);
                words = splitWords(clean);
                freq = countFreq(words);
                cout << "�ı�������ɣ�" << endl;
                break;
            }
            case 2:
                if (words.empty()) cout << "���������ı���" << endl;
                else showBasicInfo(text, words);
                break;
            case 3:
                if (words.empty()) cout << "���������ı���" << endl;
                else {
                    cout << "\n===== �ִʽ�� =====" << endl;
                    for (const string& w : words) cout << w << " ";
                    cout << endl;
                }
                break;
            case 4:
                if (freq.empty()) cout << "���������ı���" << endl;
                else showFreq(freq);
                break;
            case 5:
                if (freq.empty()) cout << "���������ı���" << endl;
                else showKeyWords(freq);
                break;
            case 6:
                if (text.empty()) cout << "���������ı���" << endl;
                else showSummary(text);
                break;
            case 7: {
                if (freq.empty()) { cout << "���������ı���" << endl; break; }
                string key; cout << "������Ҫ���ҵĵ��ʣ�"; cin >> key;
                for (int i=0;i<key.size();i++) key[i] = my_tolower(key[i]);
                cout << "���ִ�����" << searchWord(freq, key) << endl;
                break;
            }
            case 8: {
                if (text.empty()) { cout << "���������ı���" << endl; break; }
                string oldS, newS; cout << "���ң�"; cin >> oldS;
                cout << "�滻Ϊ��"; cin >> newS;
                text = replaceTextKMP(text, oldS, newS);
                string clean = preProcess(text);
                words = splitWords(clean);
                freq = countFreq(words);
                cout << "�滻��ɣ�" << endl;
                break;
            }
            case 9:
                grammarCheck(text, words);
                break;
            default:
                cout << "��Чѡ�" << endl;
        }
    }
    return 0;
}
